package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.example.entity.Account;
import com.example.entity.Employee;

import com.example.repository.AccountRepository;
import com.example.repository.EmployeeRepository;





@SpringBootApplication
public class SpringDatajpaExampleApplication implements CommandLineRunner{
	public static void main(String[] args) {
		SpringApplication.run(SpringDatajpaExampleApplication.class, args);
	}

	
	@Autowired
	EmployeeRepository ee;
	
	@Autowired
	AccountRepository ar;
	
	@Override
	public void run(String... args) throws Exception {
		Account account=new Account();
		account.setAccountNum(11111);
		account.setBalance(10000);
		
		Employee emp=new Employee();
		emp.setId(101);
		emp.setName("rv101");
		emp.setAccount(account);
		
		account.setEmployee(emp);
		
		ee.save(emp);
		System.out.println(ee.findAll());
	}
}

























//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//import com.example.entity.Employee;
//import com.example.repository.EmployeeRepository;
//
//@SpringBootApplication(scanBasePackages = "com.example")
//public class SpringDatajpaExampleApplication implements CommandLineRunner{
//
//	public static void main(String[] args) {
//		SpringApplication.run(SpringDatajpaExampleApplication.class, args);
//	}
//
//	@Autowired
//	EmployeeRepository er;
//	UserRepository ur
//	@Override
//	public void run(String... args) throws Exception {
//
//		
//		//		er.save(new Employee(101,"rv101"));
////		er.save(new Employee(102,"rv102"));
////		er.save(new Employee(103,"dv103"));
////		er.save(new Employee(104,"rv104"));
//		
//		//System.out.println(er.pqr("rv102"));
//		//System.out.println(er.findById(102));
//		//System.out.println(er.pqr("rv104"));
//		//System.out.println(er.findByEmployee(new Employee(104,"rv104")));
//		//System.out.println(er.findByName("rv102"));
//
//		//System.out.println(er.findByIdAndName(101, "rv101"));
//		
//	}
//
//}
