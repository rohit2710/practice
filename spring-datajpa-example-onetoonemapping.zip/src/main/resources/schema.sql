drop table if exists employee;
create table employee(empid int primary key, name varchar(20));
