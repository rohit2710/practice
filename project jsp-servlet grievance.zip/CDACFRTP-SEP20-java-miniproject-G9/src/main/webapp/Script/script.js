function validateName(ele) {
    let pattern = /^[A-Za-z]*[a-zA-z]$/;
    let message = "only word chracter allowed"
    addErrorMessage(ele, pattern, message)
}

function validateEmail(ele) {
    let pattern = /^[a-z]\w+@[a-z]+\.[a-z]{2,}$/i;
    let message = "invalid Email"
    addErrorMessage(ele, pattern, message)
}

function validateMobile(ele) {
    let pattern = /^[6789]{1}[0-9]{9}$/;
    let message = "invalid mobile number"
    addErrorMessage(ele, pattern, message)
}
function validatePincode(ele) {
    let pattern = /^[0-9]{6}$/;
    let message = "invalid pincode number"
    addErrorMessage(ele, pattern, message)
}
function validatePassword(ele) {
    let pattern = /^.{8,}/;
    let message = "minimum 8 character"
    addErrorMessage(ele, pattern, message)
}
function matchPassword() {
    var pass = document.getElementById('password');
    var cpass = document.getElementById('cPassword');
    var errorDiv = `<div class="alert-sm alert-danger" role="alert">
    password not matching
   </div>`

    const fragment = document.createRange().createContextualFragment(errorDiv);
    if (pass.value != cpass.value && cpass.parentElement.childElementCount < 2) {
        cpass.parentElement.appendChild(fragment);
    }
    else if (pass.value == cpass.value && cpass.parentElement.childElementCount == 2) {
        cpass.parentElement.removeChild(cpass.parentElement.lastChild)
    }

}


function addErrorMessage(ele, pattern, message) {
    var errorDiv = `<div class="alert-sm alert-danger" role="alert">
     ${message}
   </div>`
    const fragment = document.createRange().createContextualFragment(errorDiv);
    if (!ele.value.match(pattern) && ele.parentElement.childElementCount < 2) {
        ele.parentElement.appendChild(fragment);
    }
    else if (ele.parentElement.childElementCount == 2 && ele.value.match(pattern)) {
        ele.parentElement.removeChild(ele.parentElement.lastChild)
    }
}
