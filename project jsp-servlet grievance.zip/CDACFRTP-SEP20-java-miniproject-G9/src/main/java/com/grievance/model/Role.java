package com.grievance.model;
//enum for role selection
public enum Role {
	ADMIN,
	DEPARTMENTHEAD,
	CITIZEN

}
