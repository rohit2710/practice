package com.grievance.model;
//enum for select complaint status
public enum ComplaintStatus {
 PENDING,RESOLVED,INPROCESS,CLOSED
}
