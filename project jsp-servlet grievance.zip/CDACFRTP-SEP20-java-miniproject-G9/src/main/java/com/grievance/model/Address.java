package com.grievance.model;

public class Address {
	//instance variables
	private String addressId;
	private String houseNo;
	private String landMark;
	private String pincode;
	private String userId;
	
	public Address() {
		super();	
	}
	
	//parameterized constructor
	public Address(String addressId, String houseNo, String landMark, String pincode, String userId) {
		super();
		this.addressId = addressId;
		this.houseNo = houseNo;
		this.landMark = landMark;
		this.pincode = pincode;
		this.userId = userId;
	}

	//getters and setters
	public String getAddressId() {
		return addressId;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	//toString() for display variables
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", houseNo=" + houseNo + ", landMark=" + landMark + ", pincode="
				+ pincode + ", userId=" + userId + "]";
	}
	
	
	
	

}
