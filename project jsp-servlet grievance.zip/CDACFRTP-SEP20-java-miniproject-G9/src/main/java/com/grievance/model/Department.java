package com.grievance.model;


public class Department {
	//instance variables
	private String deptId;
	private String deptName;
	
	private String userId;
	
	
	public Department() {
		super();
		
	}
	
	//parameterized constructor
	public Department(String deptId, String deptName, String userId) {
		this.deptId = deptId;
		this.deptName = deptName;
		this.userId = userId;
	}

	//getters and setters
	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	//toString() for display variables
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", userId=" + userId + "]";
	}
	
	

}
