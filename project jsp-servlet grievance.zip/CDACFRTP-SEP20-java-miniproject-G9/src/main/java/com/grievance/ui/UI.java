package com.grievance.ui;

import com.grievance.dao.CitizenDaoImpl;

import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;

import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

public class UI {

	public static void main(String[] args) throws Exception {
		CitizenI citizenService = new  CitizenService();
		DepartmentI deptService =new DepartmentService();
//		EmployeeI employeeService = new EmployeeService();
//		EmployeeDaoI emDao = new EmployeeDaoImpl();
//		//System.out.println("department: " +deptService.registerDepartment("dept", "AMAN"));
////		System.out.println("landmark "+ citizenService.registerCitizen("shaan", "shaan@cybage.com", "123456", "234234", "123", "Saraswati Colony", "325205"));
//		//System.out.println("Employee "+ employeeService.registerEmployee("AMAN", "aman@cybage.com", "123456", "9123123132", "DEPARTMENTHEAD"));
////		System.out.println("employee"+employeeService.getAllFreeDeptHead());
//		System.out.println("complaint"+ employeeService.getAllComplaintsBtDeptId("D101"));
	}
}