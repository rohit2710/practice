package com.grievance.service;

import com.grievance.dao.UserDaoI;
import com.grievance.dao.UserDaoImpl;
import com.grievance.model.User;

public class UserService implements UserI {

	UserDaoI userDao = new UserDaoImpl();
	//this function is used to authenticate user
	@Override
	public User login(String email, String password) throws Exception {
		User user = userDao.loginUser(email, password);
		return user;
	}
	//this function is used to get user by email
	@Override
	public User getUserByEmail(String email) throws Exception {
		return userDao.getUserByEmail(email);
	}

}
