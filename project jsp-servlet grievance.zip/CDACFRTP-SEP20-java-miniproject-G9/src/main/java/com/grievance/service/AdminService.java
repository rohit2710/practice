package com.grievance.service;

import java.util.ArrayList;
import java.util.List;

import com.grievance.dao.AdminDao;
import com.grievance.dao.AdminDaoImpl;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;

public class AdminService implements AdminI {
	AdminDao adminDao=new AdminDaoImpl();
	
	//this function will return list of all departments
	@Override
	public List<Department> getAllDepartment() throws Exception {
		return adminDao.getAllDepartment();
		
	}
	//this function will return list of all department head
	@Override
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception {
		return new AdminDaoImpl().getAllDepartmentInfo();
	}
	
	//this function will register new department
	public String registerDepartment(String deptName, String userName) throws Exception {
		Department department = null;
		User user = adminDao.getUserByName(userName);
		System.out.println(user.toString());
		department = new Department(AdminI.getDeptId(), deptName, user.getUserId());
		int status = adminDao.addDepartment(department);
		System.out.println(status);
		if(status == 1)
		{
			return userName;
		}
		else
		{
			throw new Exception("unable to store in datbase please try again");
		}
	}

	//this function will delete department
	@Override
	public int deleteDepartment(String deptid) throws Exception {
		return adminDao.deleteDepartment(deptid);
	}

	//this function will update department 
	@Override
	public int updateDepartment(String deptName, String userName, String deptId) throws Exception {
		Department department = new Department();
		User user = adminDao.getUserByName(userName);
		System.out.println(user.toString());
		department = new Department(deptId,deptName, user.getUserId());
		return adminDao.updateDepartment(department);
	}
	
	//this function will return list of all departments
	@Override
	public List<Department> getALLDepartment() throws Exception {
		return new AdminDaoImpl().getAllDepartment();
	}

	//this function will return department info using department id
	public Department getDepartmentById(String deptId) throws Exception {
		Department department = new Department();
		department = adminDao.getDepartmentById(deptId);
		return department;
	}
	
	//this function will register new employee
	public String registerEmployee(String name, String email, String password, String mobileNo, String role) throws Exception {
		
		User user = new  User(UserI.getUserId(), name, email, password, mobileNo, role);
		
		int status = adminDao.addEmployee(user);
		if(status == 1)
		{
			return name;
		}
		else
		{
			throw new Exception("Employee cannot create please try again");
		}
	}
	
	//this function will return list of employees who are not yet assigned to any department
	@Override
	public List<User> getAllFreeDeptHead() throws Exception {
		
		List<User> users = new ArrayList<User>();
		users = adminDao.getAllFreeDeptHead();
		return users;
	}
}
