package com.grievance.dao;

import com.grievance.model.User;

public interface UserDaoI {

	public User getUserByEmail(String email) throws Exception;
	public User loginUser(String email,String password) throws Exception;
}
