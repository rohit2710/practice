package com.grievance.dao;

import java.util.List;

import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;
import com.grievance.model.Department;

public interface DepartmentDao {

	public List<Complaint> getAllComplaint() throws Exception;
	public int updateDeptRemark(String complaintId, String message) throws Exception;
	public int updateStatus(String complaintId, String status) throws Exception;
	public int transferComplaint(String complaintId, String deptId) throws Exception;
	public List<ComplaintDto> getAllComplaintByDeptId(String deptid) throws Exception;
	public List<Complaint> getAllComplaintById(String deptid) throws Exception;
	public Department getDepartmentByUserId(String userId) throws Exception ;

}
