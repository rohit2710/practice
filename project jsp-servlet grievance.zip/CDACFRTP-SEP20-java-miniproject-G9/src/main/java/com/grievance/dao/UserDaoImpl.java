package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.model.Complaint;
import com.grievance.model.Role;
import com.grievance.model.User;

public class UserDaoImpl implements UserDaoI{

	//this function is used to authenticate user
	@Override
	public User loginUser(String email, String password) throws Exception {
		String query = "select * from user where email= ? and password = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, email);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		try {
			if(rs.next()) {
				user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
			}
			return user;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ps.close();
			connection.close();
		}
		return null;
	}

	//this function is used to get user by id(admin/citizen/head)
	@Override
	public User getUserByEmail(String email) throws Exception {
		String query = "select * from user where email= ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		try {
			if(rs.next()) {
				user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
			}
			return user;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			ps.close();
			connection.close();
		}
		return null;

	}
}
