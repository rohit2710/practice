package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.model.User;
import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;
import com.grievance.service.UserI;
import com.grievance.service.UserService;

@ServletSecurity(value = @HttpConstraint(rolesAllowed = { "ADMIN", "CITIZEN", "DEPARTMENTHEAD" }))
public class AppController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CitizenI citizenService = new CitizenService();
	UserI userService = new UserService();

	public AppController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getRemoteUser();

		try {
			request.getSession().setAttribute("user", userService.getUserByEmail(email));
			User user = (User) request.getSession().getAttribute("user");
			System.out.println(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// if the login person is ADMIN then person will be redirected to admin-home
		// page
		if (request.isUserInRole("ADMIN")) {

			System.out.println(email);

//			request.getRequestDispatcher("/admin/admin-home.jsp").forward(request, response);
			response.sendRedirect("/GrievanceSyatem/admin/admin-home.jsp");
		}
		// if the login person is DEPARTMENTHEAD then person will be redirected to
		// head-home page

		if (request.isUserInRole("DEPARTMENTHEAD")) {

//			request.getRequestDispatcher("/head/head-home.jsp").forward(request, response);
			response.sendRedirect("/GrievanceSyatem/head/head-home.jsp");
		}
		// if the login person is citizen then person will be redirected to citizen-home
		// page
		if (request.isUserInRole("CITIZEN")) {
//			System.out.println("Inside citizen");
//			System.out.println(email);

//			request.getRequestDispatcher("/citizen/citizen-home.jsp").forward(request, response);
			response.sendRedirect("/GrievanceSyatem/citizen/citizen-home.jsp");
		}
		String path = request.getPathInfo();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
