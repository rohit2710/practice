package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.model.Complaint;
import com.grievance.model.ComplaintStatus;
import com.grievance.model.Department;
import com.grievance.model.User;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.Part;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
@ServletSecurity(
value = @HttpConstraint(
		rolesAllowed = {"CITIZEN"}
		)
)
@MultipartConfig( fileSizeThreshold = 1024*1024,maxFileSize = 1024*1024*5, maxRequestSize = 1024*1024*5*5)   // upload file's size up to 16MB
public class CitizenController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static final Logger logger = LogManager.getLogger(CitizenController.class.getName()); 

	CitizenI citizenService = new CitizenService();
	AdminI adminService=new AdminService();
	DepartmentI deptService = new DepartmentService();   

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		String path = request.getPathInfo();
		User user = (User) request.getSession().getAttribute("user");
		
		//this will add complaint
		if (path.equals("/addComplaint")) {
			Part filePart = request.getPart("screenshot");
			InputStream inputStream = filePart.getInputStream();
			byte[] doc = new byte[inputStream.available()];
			String complaintMsg = request.getParameter("complaintmsg");
			
//			System.out.println(user.getUserId());
			
//			getServletContext().getRequestDispatcher("/CitizenController/listComplaint").forward(request, response);
			try {
				citizenService.addComplaint(complaintMsg, doc, request.getParameter("deptId"),user.getUserId());
				logger.info("Complaint registered successfully");
				response.sendRedirect("/GrievanceSyatem/CitizenController/listComplaint");

			} catch (Exception e) {
				logger.error("Failed to register complaint");
			}
		}
		//this will show department list
		else if(path.equals("/registerComplaint")) {			
			try {
				List<Department> listDept = adminService.getALLDepartment();
				request.setAttribute("department",listDept );
				getServletContext().getRequestDispatcher("/citizen/register-complaint.jsp").forward(request, response);

			} catch (Exception e) {
				logger.error("fail to load register complaint page");
			}	
		}
		//this will show all complaints
		else if(path.equals("/listComplaint")) {
			try { 
			        List<Complaint> complaints = citizenService.getAllCitizenComplaints(user.getUserId());
			        request.setAttribute("complaints",complaints);
			        int closedCount = 0;
					int pendingCount = 0;
					if(complaints.size()>0) {
					   closedCount = complaints
							  .stream()
							  .filter(c -> c.getComplaintStatus().equals(ComplaintStatus.CLOSED.toString()))
							  .collect(Collectors.toList()).size();
					  
					   pendingCount = complaints
							  .stream()
							  .filter(c -> c.getComplaintStatus().equals(ComplaintStatus.PENDING.toString()))
							  .collect(Collectors.toList()).size();
					   
					}
				    request.setAttribute("closed", closedCount);
				    request.setAttribute("pending", pendingCount);
			        request.getRequestDispatcher("/citizen/view-complaints.jsp").forward(request, response);
			} catch (Exception e) {
				logger.error("unable to load complaint list page");
			}	
		}
		//this will edit complaint
		else if(path.equals("/editcomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				request.getRequestDispatcher("/citizen/update-complaint.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//this will update remark in case not action taken by dept-head
		else if(path.equals("/updateremark")) {
			String complaintId=request.getParameter("complaintid");
			try {
				String message = request.getParameter("message");
				citizenService.updateCitizenRemark(complaintId, message);
				logger.info("Remark updated successfully for complainId "+complaintId);
				response.sendRedirect("/GrievanceSyatem/CitizenController/listComplaint");
			} catch (Exception e) {
				logger.error("Remark updation failed for complainId "+complaintId);
			}					
		}	
		//this will send reminder in case citizen is not satiesfied with resolved complaint 
		else if(path.equals("/sendreminder")) {
			String complaintId=request.getParameter("complaintid");
			try {
				citizenService.updateReminder(complaintId);
				logger.info("Reminder sent for complainId "+complaintId);
				response.sendRedirect("/GrievanceSyatem/CitizenController/listComplaint");
			} catch (Exception e) {
				logger.info("Reminder sent failed complainId "+complaintId);
			}	
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("/CitizenController/*");
		doGet(request, response);
	}
}
