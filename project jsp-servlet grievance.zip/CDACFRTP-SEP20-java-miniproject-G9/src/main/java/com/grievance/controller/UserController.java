package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;

/**
 * Servlet implementation class UserController
 */
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger logger = LogManager.getLogger(UserController.class.getName()); 

	CitizenI citizenService=new CitizenService();
  
    public UserController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();

		//this will register user
		if (path.equals("/adduser")) {
			try {
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String houseNo = request.getParameter("houseNo");
				String landMark = request.getParameter("landmark");
				String pincode = request.getParameter("pincode");
				citizenService.registerCitizen(name, email, password, mobileNumber, houseNo, landMark, pincode);
				logger.info("new citizen registerd with name : "+name);
				response.sendRedirect("/GrievanceSyatem/index.jsp");
			} catch (Exception e) {
				logger.error("citizen registration failed ");
				e.printStackTrace();
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
