package com.grievance.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
@ServletSecurity(
value = @HttpConstraint(
		rolesAllowed = {"ADMIN"}
		)
)
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static final Logger logger = LogManager.getLogger(AdminController.class.getName()); 

	DepartmentI deptService=new DepartmentService();
	AdminI adminService=new AdminService();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		//this will add employee
		if(path.equals("/addemployee")) {		
			try {
				
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String role=request.getParameter("role");
				adminService.registerEmployee(name, email, password, mobileNumber, role);
				logger.info("Employee added successfully and employee name is "+name);
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");
			} catch (Exception e) {
				logger.error("Employee addition failed");
			}
		}
		
		if(path.equals("/registerDept")) {			
			try {
				String deptName=request.getParameter("deptname");
				String username=request.getParameter("username");
				adminService.registerDepartment(deptName, username);
				logger.info("Department added successfully by admin and department name is "+deptName);
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//this will add department
		if(path.equals("/adddept")) {			
			try {
				List<User> list=new ArrayList<User>();
				list=adminService.getAllFreeDeptHead();
				request.setAttribute("allEmployees", list);
 				request.getRequestDispatcher("/admin/add-dept1.jsp").forward(request, response);
				
			} catch (Exception e) {
				logger.info("Unable to process dept registration form");
			}
		}
		if(path.equals("/managedept")) {			
			try {
				List<Department> departments=adminService.getAllDepartment();
				List<DepartmentHeadDto> departmentInfo=adminService.getAllDepartmentInfo();
				request.setAttribute("departmentInfo",departmentInfo);
				request.setAttribute("allDepartment",departments );
				request.getRequestDispatcher("/admin/manage-dept.jsp").forward(request, response);							
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		//this will delete department
		if(path.equals("/deletedept")) {			
			try {
				adminService.deleteDepartment(request.getParameter("deptid"));
				List<Department> departments=adminService.getAllDepartment();
				request.setAttribute("allDepartment",departments );
				logger.info("Department deleted successfully");
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//this will forward request on edit department page
		if(path.equals("/editdept")) {			
			try {
				String deptId = request.getParameter("deptid");
				Department department=adminService.getDepartmentById(deptId);
				request.setAttribute("department", department);
				List<User> list=new ArrayList<User>();
				list=adminService.getAllFreeDeptHead();
				request.setAttribute("allEmployees", list);
				request.getRequestDispatcher("/admin/update-dept.jsp").forward(request, response);						
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//this will update the department
		if(path.equals("/updatedept")) {			
			try {
				String deptName = request.getParameter("deptname");
				String userName = request.getParameter("username");
				String deptId=request.getParameter("deptid");
				adminService.updateDepartment(deptName, userName, deptId);
				logger.info("Department updated successfully ");
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
