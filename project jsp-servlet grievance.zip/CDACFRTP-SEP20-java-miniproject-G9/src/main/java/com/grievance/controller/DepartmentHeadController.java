package com.grievance.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;
import com.grievance.model.ComplaintStatus;
import com.grievance.model.Department;
import com.grievance.model.User;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

public class DepartmentHeadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static final Logger logger = LogManager.getLogger(DepartmentHeadController.class.getName()); 

	DepartmentI departmentService = new DepartmentService();
	AdminI adminService = new AdminService();

	public DepartmentHeadController() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		User user = (User) request.getSession().getAttribute("user") ;
		//this will list all complaints 
		if (path.equals("/getAllComplaints")) {
			
			try {
				String departmentId = departmentService.getDepartmentByUserId(user.getUserId()).getDeptId();
				if(departmentId==null) {
					response.sendRedirect("GrievanceSyatem/error.jsp");
				}
 				List<ComplaintDto> complaints=new ArrayList<ComplaintDto>();
				complaints = departmentService.getAllComplaintsBtDeptId(departmentId);
				request.setAttribute("complaints", complaints);
				int closedCount = 0;
				int pendingCount = 0;
				if(complaints.size()>0) {
				   closedCount = complaints
						  .stream()
						  .filter(c -> c.getComplaintStatus().equals(ComplaintStatus.CLOSED.toString()))
						  .collect(Collectors.toList()).size();
				  
				   pendingCount = complaints
						  .stream()
						  .filter(c -> c.getComplaintStatus().equals(ComplaintStatus.PENDING.toString()))
						  .collect(Collectors.toList()).size();
				   
				}
			    request.setAttribute("closed", closedCount);
			    request.setAttribute("pending", pendingCount);
				logger.info("Complaint status updated successfully");
				request.getRequestDispatcher("/head/view-complaints-head.jsp").forward(request, response);
			}catch(Exception e) {
				logger.error("Failed to update Complaint status");
				response.sendRedirect("GrievanceSyatem/error-page.jsp");
			}
		}
		//this will forward request to edit page
		else if(path.equals("/editcomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				request.getRequestDispatcher("/head/update-complaint.jsp").forward(request, response);				
			} catch (Exception e) {
				logger.error("unable to process complaint update page");
			}



		}
		//this will update remark
		else if(path.equals("/updateremark")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String message = request.getParameter("message");
				departmentService.updateHeadRemark(complaintId, message);
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");				
			} catch (Exception e) {
				logger.error("unable to  update complaint");
			}
		}
		//this will forward to transfer complaint page
		else if(path.equals("/transfercomplaintform")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				List<Department> listDept = adminService.getALLDepartment();
				request.setAttribute("department",listDept);
				request.getRequestDispatcher("/head/transfer-complaint.jsp").forward(request, response);

			} catch (Exception e) {
				
			}	
		}
		//this will transfer complaint to selected department
		else if(path.equals("/transfercomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String deptId = request.getParameter("deptid");
				departmentService.transferComplaint(complaintId, deptId);
				logger.info("Complaint transferred successfully");
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");
			} catch (Exception e) {
				logger.error("Failed to transfer complaint");
			}	
		}
		//this will update complaint status
		else if(path.equals("/updatestatus")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String status = request.getParameter("status");
				departmentService.updateStatus(complaintId, status);
				logger.info("Complaint status updated successfully by department head");
				response.sendRedirect("/GrievanceSyatem/DepartmentHeadController/getAllComplaints");
			} catch (Exception e) {
				logger.info("Complaint status updation failed");
			}	
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
