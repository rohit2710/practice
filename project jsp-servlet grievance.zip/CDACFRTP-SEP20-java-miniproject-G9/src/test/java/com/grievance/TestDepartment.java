package com.grievance;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;
public class TestDepartment {
	DepartmentI departmentService=new DepartmentService();
	@Disabled
	@Test
	public void testGetAllDepartments() throws Exception{
		assertNotNull(departmentService.getAllComplaintsBtDeptId("D101"));
	}
	@Disabled
	@Test
	public void testGetAllComplaint() throws Exception{
		//checking if list empty or not...
		assertNotNull(departmentService.getAllComplaintsBtDeptId("D101"));										
	}
	@Disabled
	@Test
	public void testUpdateStatus() throws Exception{
		//after successful updation, excuteUpdate() returns 1, else 0...
		//checking if status updation is successful or not
		assertEquals(1,departmentService.updateStatus("C430", "PENDING"));				
	}
	@Disabled
	@Test
	public void testTransferComplaint() throws Exception {
		//checking if department transfer is successful or not
		assertEquals(1, departmentService.transferComplaint("C430", "D5225"));		
	}


}
