package com.grievance;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import com.grievance.service.CitizenI;
import com.grievance.service.CitizenService;
public class TestCitizen {
	CitizenI citizenService=new CitizenService();

	@Disabled
	@Test
	void testRegisterCitizen() throws Exception{
		//checking if user registration is successful or not...
		assertEquals("infoway",citizenService.registerCitizen("RV1", "RV1@gmail.com", "123456", "4865468544", "A-6", "infoway", "456789"));				
	}
	@Disabled
	@Test
	public void testGetComplaints() throws Exception {
		//checking remark updates or not
		assertEquals(1,citizenService.updateCitizenRemark("C430", "Please do at earliest"));												
	}


}
