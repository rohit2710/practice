package com.grievance;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
public class TestAdmin {
	AdminI adminService=new AdminService();
	@Disabled
	@Test
	public	 void testGetAllDeptHead() throws Exception{
		//checking if list empty or not...
		assertNotNull(adminService.getAllDepartment());
	}
	@Disabled
	@Test
	public void testAddDeptHead() throws Exception{		
		//checking if deptHead registration is successful or not...
		assertEquals(1, adminService.registerEmployee("John", "john@gmail.com", "123456", "49865489", "DEPARTMENTHEAD"));
	}
	@Disabled
	@Test
	public void testDeleteDeptHead() throws Exception{
		//checking if deptHead deletion is done or not...
		assertEquals(1, adminService.deleteDepartment("D105"));
	}
	@Disabled
	@Test
	public void testAddDept() throws Exception{
		//checking department added successfully or not
		assertEquals(1, adminService.registerDepartment("Finance1","U8350"));
	}
}
