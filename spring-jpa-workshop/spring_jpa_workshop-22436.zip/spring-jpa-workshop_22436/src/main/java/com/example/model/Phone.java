package com.example.model;

import javax.persistence.*;

@Entity
public class Phone {
	@Id
	private int number;
	public Phone() {
		// TODO Auto-generated constructor stub
	}
	public Phone(int number) {
		super();
		this.number = number;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Phone [number=" + number + "]";
	}

}
