package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.model.Customer;
import com.example.model.Phone;
import com.example.repository.CustomerRepository;

@Controller
public class CustomerController {
	@Autowired
	CustomerRepository cr;
	List<Phone> phone=new ArrayList<Phone>();
	List<Customer> customer=new ArrayList<Customer>();
	{
		customer.add(new Customer(101, "c1", "email1", "pass1", phone));
		customer.add(new Customer(102, "c2", "email1", "pass1", phone));
		customer.add(new Customer(103, "c3", "email1", "pass1", phone));
		customer.add(new Customer(104, "c4", "email1", "pass1", phone));
	}
	
	@GetMapping("/customer")
	public String customerList(Model model){
		model.addAttribute("customers",cr.findAll());
		return "customer";
	}
	
	@RequestMapping(value = "/register",method = RequestMethod.GET)
	public String getUsersForm(Model model)
	{
		model.addAttribute("customer", new Customer(111, "akshay", "email", "pass", phone));
		return "register";
		
	}
	@RequestMapping(value = "/registerdb",method = RequestMethod.POST)
	public String addUser(@ModelAttribute("customer") Customer c)
	{
		cr.save(c);
		return "customer";
		
	}
	
}
