package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cybage.dao.UserDao;

@Controller
//@RequestMapping("/user")
public class UserController {
	@Autowired(required=true)
	UserDao dao;

	@RequestMapping("/home")
	public String user() {
		return "user";
	}
	
	@GetMapping("/user")
	public String getUsers(Model model) {
		model.addAttribute("users",dao.getUsers());
		return "user";
	}
	
//	@GetMapping("/user/{id}")
//	@ResponseBody
//	public String getUser(@PathVariable int id, //@RequestParam(required = true) String name)
//			@RequestParam(defaultValue = "cybage") String name){
//		return "returning user with id:" +id +name;
//	}
	
//	@GetMapping("/user")
//	@ResponseBody
//	public String getUser() {
//		return "geting user";
//	}
//	@PostMapping("/user")
//	@ResponseBody
//	public String addUser() {
//		return "Added succesfulli";
//	}
//	
//	@DeleteMapping("/user")
//	@ResponseBody
//	public String deleteUser() {
//		return "deleted succesfulli";
//	}
	
	@RequestMapping(value="/user/{id}",method = RequestMethod.GET)
	public String deleteUser(@PathVariable int id) {
		dao.deleteById(id);
		return "redirect:/user";
	}
	@RequestMapping(value="/edituser/{id}",method = RequestMethod.GET)
	public String updateUser(@PathVariable int id, Model model) {
		model.addAttribute("user",dao.findById(id));
		dao.deleteById(id);
		return "edituser";
	}
	
	
	
//	
//	@PutMapping("/user")
//	@ResponseBody
//	public String updateUser() {
//		return "updated succesfulli";
//	}
}
