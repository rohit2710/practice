package com.cybage.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.controller.Users;

@Repository
public class UserDao {
	List<Users> users = new ArrayList<>();
	{
		users.add(new Users(101, "rv101"));
		users.add(new Users(102, "rv102"));
		users.add(new Users(103, "rv103"));
		users.add(new Users(104, "rv104"));

	}
	public List<Users> getUsers() {
		return users;
	}
	
	public void deleteById(int id) {
		users.removeIf(u -> u.getId() == id);
	}

	public Object findById(int id) {
		users
		.stream()
		.filter(u -> u.getId() == id)
		.findFirst();
		return null;
	}
}
