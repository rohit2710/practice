package com.demo.model;

import javax.persistence.*;

@Entity
public class Phone {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer phoneId;
	
	private Integer phoneNumber;
	
	public Phone() {
	}

	public Phone(Integer phoneId, Integer phoneNumber) {
		super();
		this.phoneId = phoneId;
		this.phoneNumber = phoneNumber;
	}

	public Integer getPhoneId() {
		return phoneId;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneId(Integer phoneId) {
		this.phoneId = phoneId;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Phone [phoneId=" + phoneId + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
	


}
