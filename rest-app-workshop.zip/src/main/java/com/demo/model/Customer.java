package com.demo.model;
import java.util.List;

import javax.persistence.*;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer custId;
	private String customername;
	private String email;
	private String password;
	@OneToMany(
			targetEntity = Phone.class, 
			fetch = FetchType.EAGER,
			cascade = CascadeType.ALL			
			)
	@JoinColumn(name = "cust_phone_fk", referencedColumnName = "custId")
	private List<Phone> phones;
	
	public Customer() {
	
	}

	public Customer(int custId, String customername, String email, String password, List<Phone> phones) {
		super();
		this.custId = custId;
		this.customername = customername;
		this.email = email;
		this.password = password;
		this.phones = phones;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Phone> getPhones() {
		return phones;
	}

	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}
	
	public void addPhone(Phone phone) {
		this.phones.add(phone);
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", customername=" + customername + ", email=" + email + ", password="
				+ password + ", phones=" + phones + "]";
	}
	
}
