package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Customer;
import com.demo.repository.CustomerRepository;
import com.demo.repository.PhoneRepository;

@RestController
@RequestMapping("customer")
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private PhoneRepository  phoneRepository;
	//http://localhost:8080/customer
	@GetMapping
	public List<Customer>  getallCustomers(){
		return this.customerRepository.findAll();
	}
	//http://localhost:8080/customer
//    {
//        "custId": null,
//        "customername": "hmmm",
//        "email": "hmm@",
//        "password": "hmmm",
//        "phones": [
//            {
//                "phoneId": null,
//                "phoneNumber": 1458545
//            }
//        ]
//    }
	@PostMapping
	public Customer addCustomer(@RequestBody Customer customer) {
		this.customerRepository.save(customer);

		return null;
	}
//	   http://localhost:8080/customer
//	    {
//	        "custId": 8,
//	        "customername": "bhava",
//	        "email": "hmm@",
//	        "password": "hmmm",
//	        "phones": [
//	            {
//	                "phoneId": null,
//	                "phoneNumber": 1458545
//	            }
//	        ]
//	    }
	@PutMapping
	public Customer updateCustomer(@RequestBody Customer customer) {
		    Customer cust = this.customerRepository.findById(customer.getCustId()).orElseThrow();
            cust.setCustomername(customer.getCustomername());
            this.customerRepository.save(cust);
		return null;
	}
	
	//http://localhost:8080/customer/8
	@DeleteMapping
	@RequestMapping("/{id}")
	public void deleteCustomer(@PathVariable Integer id) {
		System.out.println(id);
		this.customerRepository.deleteById(id);
	}
	
	//http://localhost:8080/customer/paging?pagenum=1
	@GetMapping("/paging")
    public List<Customer> customerpage(@RequestParam int pagenum){
           
           Pageable page = PageRequest.of(pagenum, 2);
      return this.customerRepository.findAll(page).getContent();
           
    }

	

	
	
	
	
}
