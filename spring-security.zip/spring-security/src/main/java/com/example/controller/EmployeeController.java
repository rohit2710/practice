package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@RequestMapping("/")
	public ModelAndView index() {
		return new ModelAndView("index");
	}
	@RequestMapping("/admin")
	public ModelAndView user() {
		return new ModelAndView("admin");
	}
	@RequestMapping("/user")
	public ModelAndView admin() {
		return new ModelAndView("user");
	}
}
