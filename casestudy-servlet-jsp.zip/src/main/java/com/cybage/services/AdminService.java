package com.cybage.services;
import java.util.List;
import com.cybage.dao.AdminDao;
import com.cybage.model.Users;
public class AdminService {
    AdminDao adminDao = new AdminDao();
    public List<Users> getUsers() throws Exception{
        return adminDao.getUsers();
    }
}