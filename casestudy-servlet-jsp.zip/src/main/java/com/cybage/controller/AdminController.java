package com.cybage.controller;

 

import java.io.IOException;
import java.util.List;

 

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

import com.cybage.model.Users;
import com.cybage.services.AdminService;

 

public class AdminController extends HttpServlet {
    AdminService as = new AdminService();
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getPathInfo();
        if(path.equals("/listuser")) {            
            try {
                List<Users> users =  as.getUsers();
                request.setAttribute("users", users);
                request.getRequestDispatcher("/admin/admin-user.jsp").forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
     }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

 

}