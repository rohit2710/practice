package com.cybage.dao;

public class AdminDao {
	
}
