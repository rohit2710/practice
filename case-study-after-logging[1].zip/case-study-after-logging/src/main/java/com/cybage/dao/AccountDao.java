package com.cybage.dao;

import com.cybage.Account;
import com.cybage.AccountException;

public interface AccountDao {
	public String addAccount(Account account) throws Exception;
	public double getBalance(String accNumber) throws AccountException, Exception;
}
