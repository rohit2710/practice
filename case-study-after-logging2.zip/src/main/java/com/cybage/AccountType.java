package com.cybage;

public enum AccountType {
	SAVING,
	CURRENT,
	CREDITCARD,
	HOMELOAN,
	CARLOAN,
	EDUCATIONLOAN
}
