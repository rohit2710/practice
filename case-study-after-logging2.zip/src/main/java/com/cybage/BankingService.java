package com.cybage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cybage.dao.AccountDao;
import com.cybage.dao.AccountDaoImpl;
import com.cybage.dbutil.DbUtil;

//this class is specific certain project
public class BankingService implements Banking{
	CustomerService cs = new CustomerService();
	AccountDao dao = new AccountDaoImpl();
	public static final Logger logger = LogManager.getLogger(BankingService.class.getName());
	//generateAccNumber
	private String generateAccNumber(){
		return "H"+ Math.round(Math.random()*99999);
	}
	//function to open to open account
	@Override
	public String openAccount(String accType,
			String name, 
			String address, 
			double balance) throws AccountException, Exception
		{		
		if(balance < 10000){
			throw new AccountException("Cannot create account as amount is less than 10000");
		}
		 

		//1. create customer
		Customer c1 = cs.addCustomer(name, address);
		//store customer in database
		//logically this code should go to customerdao
		String sql = "insert into customer values(?, ?, ?)";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, c1.getCustId());
		ps.setString(2, c1.getCustName());
		ps.setString(3, c1.getCustAddress());
		ps.executeUpdate();	
		
		
		//need to create account and store in database
		Account account = null;
		switch (accType) {
		case "SAVING":	
			account = new SavingAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		case "CURRENT":
			account = new CurrentAccount(generateAccNumber(), accType, c1.getCustId(), balance);
			break;
		default: 
			account = null;
		}
		ps.close();
		con.close();
		String createdAccount = dao.addAccount(account);
		logger.info("Account created with account number: "+ createdAccount);
		return createdAccount;
	}
	
	//get balance function
	@Override
	public double getBalance(String accNumber) throws AccountException, Exception{
		///adding blanace in logger but not recommended..
		double balance = dao.getBalance(accNumber);
		logger.info("Account balance is checked with account number: "+  accNumber+" balance is "+balance);
		return balance;		
	}
	//calculate rate of interest function
	@Override
	public double calculateROI(String accNumber) throws AccountException, Exception{
		//calculating rate of interest
		String accType=this.getAccType(accNumber);
		if(accType.equals("SAVING")) {
			return Math.round(dao.getBalance(accNumber)*(Banking.roiSaving/100));	
		}
		return Math.round(dao.getBalance(accNumber)*(Banking.roiCurrent/100));		
	}

	//function to withdrawl ammount
	@Override
	public String withdrawl(String accNumber, double amount) throws AccountException {
		try {
			boolean flag=dao.withdrawl(accNumber, amount);
			if(flag==true) {
				logger.info("money withdrawl with account number: "+  accNumber+" withdrawl ammount "+amount);

			}else {
				logger.error("money withdrawl failed with entered account number: ");
				throw new AccountException("withdrawl failed.....");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return accNumber;
	}
	//function to display all account
	@Override
	public void displayAllAccounts() {
		try {
			List<Account> accounts=dao.getAllAccounts();
			for(Account account:accounts) {
				System.out.println(account);
			}
		} catch (Exception e) {
			e.getMessage();
		}
		
	}
	@Override
	public String getAccType(String accNumber) throws AccountException, Exception {
		return dao.getAccountType(accNumber);
	}
	

}