package com.cybage;

public interface iCustomer {
	public Customer addCustomer(String name, String address);
	//more methods
}
