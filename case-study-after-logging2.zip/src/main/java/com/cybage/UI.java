package com.cybage;

import java.util.Scanner;

import com.cybage.dao.AccountDaoImpl;
import com.cybage.dbutil.DbUtil;

public class UI {
	public static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws Exception{
		System.out.println("Welcome to HDFC bank");
		BankingService bs = new BankingService();
		do{
		    System.out.println("please select your choice: ");
		    System.out.println("1.Create Account");
		    System.out.println("2.Get Balance");
		    System.out.println("3.Calculate Rate of interest");
		    System.out.println("4.Withdral an ammount");
		    System.out.println("5.Get All accounts");

		    int choice = sc.nextInt(); 
		    switch (choice) {
		       case 1: 
		    	   //create account
		    	   System.out.println("Please enter name :");
		    	   String name=sc.next();
		    	   System.out.println("Please enter city :");
		    	   String city=sc.next();
		    	   System.out.println("Please enter ammount the initial deposited ammount : ");
		    	   double ammount=sc.nextDouble();
		    	   System.out.println("select type of account : 1.current 2.saving");
		    	   int var=sc.nextInt();
		    	   if(var==1) {
			    	   bs.openAccount(AccountType.CURRENT.toString(), name, city, ammount);
		    	   }else {
			    	   bs.openAccount(AccountType.SAVING.toString(), name, city, ammount);
		    	   }
		    	   break;
		       
		       
		     case 2:
		       //get balance
		    	 System.out.println("Enter account number : " );
		 		 System.out.println("avaliable balance: " + bs.getBalance(sc.next()));		
		 		 break;      
		        
		     case 3:
		    	 //Calculate Rate of interest
		    	 System.out.println("Enter account number : " );
		 		 System.out.println("Rate of interest : " + bs.calculateROI(sc.next()));

		       break;      
		     case 4:
		    	 //withdrawl
		    	 System.out.println("Enter account number and ammount to withdwawl : " );
		 		 bs.withdrawl(sc.next(), sc.nextDouble());
		    	 
		       break;      
		     case 5:
		    	 //get all accounts
		    	 bs.displayAllAccounts();
		       break; 
		     default:
		       break;
		     }
		     }
		      while(true);
		//value will come from html page from user
		//bs.openAccount(AccountType.CURRENT.toString(), "dm104", "pune124", 20000);

		//getting balance
		//System.out.println("avaliable balance: " + bs.getBalance("H78894"));		
		//getting rate of interest
		//System.out.println("Rate of interest : " + bs.calculateROI("H78894"));
		//display all accounts
		//bs.displayAllAccounts();
		//withdrawlAmmount
		//bs.withdrawl("H78894", 1532.0);
		
	}
}