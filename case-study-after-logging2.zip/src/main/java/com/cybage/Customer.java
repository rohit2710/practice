package com.cybage;

public class Customer {
	
	private String custId;
	private String custName;
	private String custAddress;
	
	public Customer() {
		super();		
	}
	public Customer(String custId, String custName, String custAddress) {
		super();		
		this.custId = custId;
		this.custName = custName;
		this.custAddress = custAddress;
	}
	public String getCustId() {
		return custId;
	}
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	//if we want string representation of object then override toString method
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custAddress=" + custAddress + "]";
	}
}
