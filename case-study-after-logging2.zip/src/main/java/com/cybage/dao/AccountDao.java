package com.cybage.dao;

import java.util.List;

import com.cybage.Account;
import com.cybage.AccountException;

public interface AccountDao {
	public String addAccount(Account account) throws Exception;
	public double getBalance(String accNumber) throws AccountException, Exception;
	public String getAccountType(String accNumber) throws AccountException, Exception;
	public List<Account> getAllAccounts() throws Exception;
	public boolean withdrawl(String accNumber,double withdrawlAmmount)throws AccountException, Exception;
}
