package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cybage.Account;
import com.cybage.AccountException;
import com.cybage.dbutil.DbUtil;

public class AccountDaoImpl implements AccountDao{

	//function to addAccount
	@Override
	public String addAccount(Account account) throws Exception {
		String sql = "insert into account values(?, ?, ?, ?)";
		Connection con = DbUtil.getConnection();		//new object
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, account.getAccNumber());
		ps.setString(2, account.getAccType());
		ps.setString(3, account.getCustId());
		ps.setDouble(4, account.getBalance());

		if(ps.executeUpdate() == 1) {
			con.commit();			//customer + account will be committed
			ps.close(); 
			con.close();  
			return account.getAccNumber();
		}
		else{ 
			con.rollback();
			ps.close(); 
			con.close(); 
			return null;
		}
	}
	//function to get balance
	@Override
	public List<Account> getAllAccounts() throws Exception {
		ArrayList<Account> accounts =new ArrayList<>();
		String sql = "select * from account";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs= ps.executeQuery();
        while( rs.next( ) ) {
            String accNumber = rs.getString(1);
            String accType = rs.getString(2);
            String custId = rs.getString(3);

            double balance = rs.getDouble(4);
            Account account=new Account(accNumber,accType,custId,balance) {
			};
			accounts.add(account);
        }
		return accounts;
	}
	//function to get balance
	@Override
	public double getBalance(String accNumber) throws AccountException, Exception {
		String sql = "select balance from account where accnumber = ?";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, accNumber);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			double temp = rs.getDouble(1);
			rs.close();
			ps.close();			
			con.close();
			return temp;
		}else{
			rs.close();
			ps.close();			
			con.close();
			throw new AccountException("account doesnot exists...");
		}
	}
	//function to withdrawl ammount
	@Override
	public boolean withdrawl(String accNumber, double withdrawlAmmount) throws Exception,AccountException {
		double availableBalance = this.getBalance(accNumber);
		if(availableBalance<withdrawlAmmount) {
			throw new AccountException("insufficient balance.....");
		}else {
			double updatedBalance=availableBalance-withdrawlAmmount;
			String sql = "UPDATE account SET balance = ? WHERE accnumber = ?";
			Connection con = DbUtil.getConnection();			//new object
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, updatedBalance);
			ps.setString(2, accNumber);
			int rs=ps.executeUpdate();
			if(rs>0) {
				return true;
			}else {
				throw new AccountException("Balance is not updated.....something went wrong");
	
			}
			
		}
	}
	@Override
	public String getAccountType(String accNumber) throws AccountException, Exception {
		String sql = "select accType from account where accnumber = ?";
		Connection con = DbUtil.getConnection();			//new object
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, accNumber);
		ResultSet rs= ps.executeQuery();
		if(rs.next()){
			String temp = rs.getString(1);
			rs.close();
			ps.close();			
			con.close();
			return temp;
		}else{
			rs.close();
			ps.close();			
			con.close();
			throw new AccountException("account doesnot exists...");
		}
	}
}
