package com.cybage;

//banking rules will be defined by rbi and all bank need to adhere to rbi rules
public interface Banking {
	public static double roiSaving = 7;
	public static double roiCurrent = 8;

	public String openAccount(
			String accType, 
			String name, 
			String address, 
			double balance
			) throws AccountException, Exception;
	public double getBalance(String accNumber) throws AccountException, Exception;
	public String getAccType(String accNumber) throws AccountException, Exception;

	public double calculateROI(String accNumber) throws AccountException, Exception;
	public String withdrawl(String accNumber, double amount) throws AccountException;
	public void displayAllAccounts();
	
}
