package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import com.example.model.Users;

@RestController		// @Controller + responce body
@RequestMapping("/users")		// http://localhost:8283/users +method type
//@CrossOrigin(origins = {"http://127.0.0.1:5500", "http://127.0.0.2:5500"})
public class UserController {
	
	List<Users> users = new ArrayList<Users>();
	{
		users.add(new Users(101, "dm101", "swimming", 35));
		users.add(new Users(102, "dm102", "running", 36));
		users.add(new Users(103, "dm103", "cycling", 37));
		users.add(new Users(104, "dm104", "dancing", 38));
		users.add(new Users(105, "dm105", "reading", 39));
		users.add(new Users(106, "dm106", "travelling", 40));				
	}
	
	
	@GetMapping(value ="/xml" , produces = MediaType.APPLICATION_XML_VALUE)
	public  ResponseEntity<?> getUsersXml(){
		if(users.size() == 0) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("no users found in db");
		}else {
			return ResponseEntity.status(HttpStatus.FOUND).body(users);			
		}							
	}
	
	@GetMapping(value = "/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(code = HttpStatus.FOUND)
	public List<Users> getUsersJson(){
		return users;				
	}
	
	@GetMapping("/{id}")
	public Optional<Users> getUser(@PathVariable int id){
if(10==10) {
throw new 
ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "both number are equal");
}
	 		
		return users.stream().filter(u -> u.getId() ==id ).findFirst(); 
	}
	
	@PostMapping
	public String addUsers(@RequestBody Users user){
		users.add(user);
		return "successfully added record: "+ user;
	}
	
	@PutMapping("/{id}")
	public String updateUsers(@RequestBody Users user, @PathVariable int id){
		users.removeIf(u -> u.getId() == id);
		users.add(user);
		return "successfully updated record: "+ user;
	}
	@DeleteMapping("/{id}")
	public String deleteUsers(@PathVariable int id){
		users.removeIf(u -> u.getId() == id);
		return "successfully deleted record: " +id;
	}
}
