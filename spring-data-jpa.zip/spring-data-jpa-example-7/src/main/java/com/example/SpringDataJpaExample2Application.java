package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}
	
	@Autowired
	EmployeeRepository er;
	
	@Autowired
	AccountRepository ar;
	
	@Override
	public void run(String... args) throws Exception {
		 Account account = new Account();
		 account.setAccountNum(11111);
		 account.setBalance(10000);
		 
		 Employee emp = new Employee();
		 emp.setId(101);
		 emp.setName("dm101");
		 emp.setAccount(account);
		 
		 account.setEmployee(emp);
		 
		 
		 er.save(emp);
		 
		 System.out.println(er.findAll());
	}
}
