package com.example;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Account {
	@Id	
	private int accountNum;
	private int balance;
	
	@OneToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name="id", nullable = false)
	private Employee employee;
	
	public Account() {
		super();
	}
	public Account(int accountNum, int balance, Employee employee) {
		super();
		this.accountNum = accountNum;
		this.balance = balance;
		this.employee = employee;
	}
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Account [accountNum=" + accountNum + ", balance=" + balance + ", employee=" + employee + "]";
	}
	
}
