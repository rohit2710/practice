package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}
	
	@Autowired
	EmployeeRepository er;
	
	@Autowired
	AccountRepository ar;
	
	@Override
	public void run(String... args) throws Exception {
		 List<Account> accounts = new ArrayList<Account>();
		 accounts.add(new Account(5551, 10000));
		 accounts.add(new Account(5552, 20000));
		 accounts.add(new Account(5553, 30000));
		 
		 Employee employee = new Employee(101, "dm101", accounts);
		 
		 er.save(employee);
		 System.out.println(er.findById(101));
		 
		 
		 
		 System.out.println("-----------------------------");
		 List<Account> account1 = new ArrayList<Account>();
		 account1.add(new Account(5555, 40000));
		 account1.add(new Account(5556, 50000));
		 account1.add(new Account(5557, 60000));
		 
		 Employee emp1 = new Employee(102, "dm102", account1);
		 
		 er.save(emp1);
		 System.out.println(er.findById(102));
		 System.out.println("-----------------------------");
		 System.out.println(er.getAccounts());
		 
	}
}
