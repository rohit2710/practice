package com.example;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	@Id
	private int empId;
	private String name;
	
	@OneToMany(
			targetEntity = Account.class, 
			fetch = FetchType.EAGER,
			cascade = CascadeType.ALL			
			)
	@JoinColumn(name = "ea_fk_empid", referencedColumnName = "empId")
	private List<Account> account;
	public Employee() {
		super();
	}
	public Employee(int empId, String name, List<Account> account) {
		super();
		this.empId = empId;
		this.name = name;
		this.account = account;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", account=" + account + "]";
	}
}
