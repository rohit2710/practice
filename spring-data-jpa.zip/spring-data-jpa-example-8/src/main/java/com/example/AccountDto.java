package com.example;

public class AccountDto {
	private String name;
	private int accountNum;
	public AccountDto() {
		super();
	}
	public AccountDto(String name, int accountNum) {
		super();
		this.name = name;
		this.accountNum = accountNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	@Override
	public String toString() {
		return "AccountDto [name=" + name + ", accountNum=" + accountNum + "]";
	}
	
}
