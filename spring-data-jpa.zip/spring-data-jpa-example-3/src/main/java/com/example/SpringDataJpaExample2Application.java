package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}

	@Autowired
	EmployeeRepository er;
	
	@Override
	public void run(String... args) throws Exception {
		//save some record
		
		List<String> phones = new ArrayList<String>();
		phones.add("123456");
		phones.add("123457");
		phones.add("123458");
		
		Employee emp1 = new Employee();
		emp1.setId(101);
		emp1.setName("dm101");
		emp1.setPhones(phones);
		
		er.save(emp1);
		
		
		List<String> phone1 = new ArrayList<String>();
		phone1.add("123451");
		phone1.add("123452");
		phone1.add("123453");
		
		Employee emp2 = new Employee();
		emp2.setId(102);
		emp2.setName("dm102");
		emp2.setPhones(phone1);
		
		er.save(emp2);
		
		System.out.println(er.findAll());
		
	}
}
