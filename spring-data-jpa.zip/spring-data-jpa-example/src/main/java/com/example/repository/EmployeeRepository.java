package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee	, Integer>{
	//public List<Employee> xyz(String n);	//implementation will be given by jpa repository
	//public List<Employee> abc(String n);	//implementation will be given by jpa repository
	
	@Query("select e.name from Employee e where e.name = ?1")	//jpql
	public List<String> pqr(String nm);
	
//	@Query(name = "select * from employee where name = ?1", nativeQuery = true)	//sql
//	public List<Employee> findByName(String name);
}
