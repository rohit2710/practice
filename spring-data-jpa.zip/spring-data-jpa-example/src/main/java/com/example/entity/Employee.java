package com.example.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;

@Entity
//@NamedQuery(
//		name = "Employee.xyz", 
//		query = "select e from Employee e where e.name = ?1"
//		)
//@NamedNativeQuery(
//		name = "Employee.abc",
//		query = "select emp_id, name from employee where name = ?1",
//		resultClass = Employee.class
//		)
public class Employee {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	private String name;
	public Employee() {
		super();
	}
	public Employee(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + "]";
	}	
}