package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Employee;
import com.example.repository.EmployeeRepository;

@SpringBootApplication (scanBasePackages = "com.example")
public class SpringDataJpaExampleApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExampleApplication.class, args);
	}

	@Autowired
	EmployeeRepository er;
	
	@Override
	public void run(String... args) throws Exception {
		//adding record in the database...
		er.save(new Employee(101, "dm101"));
		er.save(new Employee(102, "e102"));
		er.save(new Employee(103, "dm103"));
		er.save(new Employee(104, "f101"));
		
		System.out.println(er.pqr("dm101"));
	}

}
