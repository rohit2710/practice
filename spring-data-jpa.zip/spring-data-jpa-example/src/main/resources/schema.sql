drop table if exists employee;
create table employee(id int primary key, name varchar(20));