insert into employee values(101, 'dm101');
insert into employee values(102, 'dm102');
insert into employee values(103, 'dm103');
insert into employee values(104, 'dm104');
insert into employee values(105, 'dm105');