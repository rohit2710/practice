package com.example;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "RETIRED")
public class Retired extends Employee{
	private int pension;

	public Retired() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Retired(int id, String name, int pension) {
		super(id, name);
		this.pension = pension;
	}

	public int getPension() {
		return pension;
	}

	public void setPension(int pension) {
		this.pension = pension;
	}

	@Override
	public String toString() {
		return "Retired [pension=" + pension + ", getId()=" + getId() + ", getName()=" + getName() + "]";
	}	
}
