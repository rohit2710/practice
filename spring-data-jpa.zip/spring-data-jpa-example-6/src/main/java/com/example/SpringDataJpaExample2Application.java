package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}
	
	@Autowired
	RegularRepository regRepo;
	
	@Autowired
	RetiredRepository retiredRepo;
	
	@Override
	public void run(String... args) throws Exception {
		 Employee re = new Regular(101, "dm101", 123);
		 Employee retired = new Retired(102, "dm102", 456);
		 
		 regRepo.save(re);
		 retiredRepo.save(retired);
		 
		 System.out.println(regRepo.findAll());
		 System.out.println(retiredRepo.findAll());
	}
}
