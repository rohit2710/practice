package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}

	@Autowired
	UserRepository ur;
	
	@Override
	public void run(String... args) throws Exception {
		//add some records
		ur.save(new User("a", "swimming", 35));		
		ur.save(new User("b", "running", 40));
		ur.save(new User("c", "cycling", 25));
		ur.save(new User("d", "dancing", 39));
		ur.save(new User("e", "swimming", 42));
		ur.save(new User("f", "running", 22));
		ur.save(new User("g", "swimming", 38));
		ur.save(new User("a", "swimming", 35));
		ur.save(new User("b", "running", 40));
		ur.save(new User("c", "cycling", 25));
		ur.save(new User("d", "dancing", 39));
		ur.save(new User("e", "swimming", 42));
		ur.save(new User("f", "running", 22));
		ur.save(new User("g", "swimming", 38));
		System.out.println("---------------------------------");
		System.out.println(ur.findAll());
		System.out.println("---------------------------------");
		System.out.println("pagination");
		
		System.out.println(ur.findByHobby("swimming", PageRequest.of(0, 2)));
		System.out.println("---------------------------------");
		System.out.println(ur.findAllRecords(PageRequest.of(0, 2)));
	}
}
