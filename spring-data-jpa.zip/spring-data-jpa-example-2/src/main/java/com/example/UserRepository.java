package com.example;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository 
extends JpaRepository<User, Integer>{
	public List<User> findByHobby(String hobby, Pageable pr);

	@Query(value = "select * from user", nativeQuery = true)
	public List<User> findAllRecords(Pageable p);
}
