package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@SpringBootApplication
public class SpringDataJpaExample2Application implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExample2Application.class, args);
	}

	@Autowired
	EmployeeRepository er;
	
	@Autowired
	RegularRepository rr;
	
	@Autowired
	RetiredRepository retiredRepo;
	
	@Override
	public void run(String... args) throws Exception {
		 Employee e1 = new Employee(101, "dm101");
		 
		 Employee r1 = new Regular(102, "regemp102", 123);
		 
		 Employee re1 = new Retired(103, "retiredemp103", 456);
		 
		 
		 er.save(e1);
		 rr.save(r1);
		 retiredRepo.save(re1);
		 
		 System.out.println(er.findById(1));
		 System.out.println(rr.findById(2));
		 System.out.println(retiredRepo.findById(3));
	}
}
