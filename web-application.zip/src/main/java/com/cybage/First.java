package com.cybage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class First extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public First() {
		System.out.println("First servlet created");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.print("<h1>Welcome to servlet programming</h1>");
		response.getWriter().append("<h1>Welcome to servlet programming</h1>");
		out.print(request.getContentLength());
		out.print(request.getContextPath());
		out.print(request.getRequestURI());
		out.print("request parameter "+request.getParameter("name"));
		//request dispatcher
		//redirecting to second servlet
		//request.getRequestDispatcher("Second").forward(request, response);
		//request.getRequestDispatcher("Second").include(request, response);

		response.sendRedirect("http://www.cybage.com");

	}

}
