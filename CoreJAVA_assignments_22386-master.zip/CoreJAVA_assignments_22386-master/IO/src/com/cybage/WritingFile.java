package com.cybage;

 

import java.io.FileInputStream;
import java.io.FileOutputStream;

 

public class WritingFile {
    public static void main(String[] args) throws Exception{
        FileOutputStream output = new FileOutputStream("output.txt", true);
        String data = "this data will be written inside file...";
        output.write(data.getBytes());
        output.flush();            //it will save data in file
        output.close();
    }
}
 