package com.cybage;

 

import java.io.FileInputStream;
import java.io.FileOutputStream;

 

public class CopyFile {
    public static void main(String[] args) throws Exception{
        FileInputStream input = new FileInputStream("input.txt");
        FileOutputStream output = new FileOutputStream("output.txt", true);
        
        int data = 0;
        while( (data = input.read()) != -1){
            output.write(data);
        }
        output.flush();
        output.close();
        input.close();
    }
}
 