package com.cybage;

 

import java.io.FileInputStream;

 

public class ReadingFile {
    public static void main(String[] args) throws Exception{
        FileInputStream input = new FileInputStream("input.txt");
        int data = 0;
        while(  (data = input.read()) != -1  ){
            System.out.print((char)data);
        }
    }
}