package com.cybage;

public class Employee {
	private int empId;
	private String empName;
	private double empSalary;
	
	
	//without using parametrised constructor
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}



	//initialise the members
	public Employee(int empId, String empName, double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	
	
	public double calculateSalary(){
		 return empSalary;
				 
		
	}
	

}
