package com.cybage;

public class Manager extends Employee {
	private int allowanceField;
	
	

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Manager(int empId, String empName, double empSalary) {
		super(empId, empName, empSalary);
		// TODO Auto-generated constructor stub
	}



	public Manager(int allowanceField) {
		super();
		this.allowanceField = allowanceField;
	}
	
	

}
