package com.cybage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Program {

	 public static Date getLastDateOfMonth(Date date){
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(date);
	        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
	        return cal.getTime();
	    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Current date and time
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		System.out.println(df.format(dateobj));
		
		//using LocalDate Api
		LocalDateTime ldt=  LocalDateTime.now();
		System.out.println(ldt);
		//lets see how we can display the current date time in different format
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm a");  
        String newFormat = ldt.format(format);  
        System.out.println("Current Date Time in specified format: "+newFormat);  
		
		
		//last day of month
        System.out.println("Last day of the month: " + getLastDateOfMonth(new Date()));
      
	}

}
