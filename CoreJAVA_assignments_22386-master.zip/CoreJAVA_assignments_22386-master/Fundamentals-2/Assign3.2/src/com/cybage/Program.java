package com.cybage;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee[] emps= new Employee[5];
		
		emps[0]= new Employee(22385,"Darshan",15000);
		emps[1]= new Employee(22386,"Deepika",15000);
		emps[2]= new Employee(22384,"Barkha",15000);
		emps[3]= new Employee(22382,"Amar",15000);
		emps[4]= new Employee(22322,"Animesh",15000);
		
		//Accessing specified elements in the array
		 for (int i = 0; i < emps.length; i++) 
	            System.out.println("Employee at " + i + " : " + 
	                        emps[i].getEmpId() +" "+ emps[i].getEmpName() +" "+ emps[i].getSalary()); 

	}

}
