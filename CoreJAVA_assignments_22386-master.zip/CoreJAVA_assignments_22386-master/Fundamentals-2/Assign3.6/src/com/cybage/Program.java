package com.cybage;

import java.util.Scanner;
import static java.lang.Math.*;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		 System.out.print("Enter the radius: ");
	    
	      double radius = sc.nextDouble();
	      //Area = PI*radius*radius
	      double area = PI * (radius * radius);
	      System.out.println("The area of circle is: " + area);

	      sc.close();
	}

}
