package com.cybage;

import java.util.Scanner;

public class Program {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		try{
			System.out.println("Enter a number:");
			int num=sc.nextInt();
			if(num < 0) throw new RuntimeException();
			System.out.println("Square root of a number:"+Math.sqrt(num));
			
			
		}
		catch(RuntimeException e){
			System.out.println("Negative number can't be accepted ");
		}
		finally{
			sc.close();
		}
		
		

	}

}
