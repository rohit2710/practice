package com.cybage;

public class Main5 {

	// method which divide two numbers 
    public static void divide(int a, int b) 
        throws ArithmeticException 
    { 
  
        int c = a / b; 
  
        System.out.println("Result:" + c); 
    } 
	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		 try { 
			  
	            // divide the numbers 
	            divide(2, 0); 
	        } 
	  
	        catch (ArithmeticException e) { 
	  
	            System.out.println("Message String = "+ e.getMessage()); 
	        } 
	}

}
