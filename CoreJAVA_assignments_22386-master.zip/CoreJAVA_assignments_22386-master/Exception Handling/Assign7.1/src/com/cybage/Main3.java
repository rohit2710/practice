package com.cybage;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			System.out.println("Try block");
			int num=45/0;
		    System.out.println(num);
			
		}
		//It goimg to be executed without catch block
		finally{
			System.out.println("Finally block");
		}

	}

}
