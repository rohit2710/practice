package com.cybage;

public class Main4 {

	void method3(){
	    int result = 100 / 0;  //Exception Generated
	  }

	  void method2(){
	    method3();
	  }

	  void method1(){
	    try{
	  method2();
	    } catch(Exception e){
	  System.out.println("Exception is handled here");
	    }
	  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      Main4 obj=new Main4();
		  obj.method1();
		  System.out.println("Continue with Normal Flow...");
		  

	}

}
