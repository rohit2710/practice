package com.cybage;

public class Date {
	private int day;
	private int month;
	private int year;
	
	
	
	//non-parametrised constructor
	public Date() {
		super();
		// TODO Auto-generated constructor stub
	}




	//initialise fields using parameters
	public Date(int day, int month, int year) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
	}


	


	
	



	@Override
	public String toString() {
		return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
	}
	
	
	
	

}
