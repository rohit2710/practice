package com.cybage;


public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date= new Date(22,10,2020);
		
		
		
		System.out.println(" date:"+date.toString());
	

	}

}
