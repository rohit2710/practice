package com.cyabge;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int m, n = 0, sum=0;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter number of six digit  non-negative:");
		 n= sc.nextInt();
		 
		while(n >0){
			 m= n%10;
			 sum= sum+m;
			 n=n/10;
			
			 
		 }
		
		 System.out.printf("Sum of digits:%d",sum);
		 sc.close();

	}
	

}
