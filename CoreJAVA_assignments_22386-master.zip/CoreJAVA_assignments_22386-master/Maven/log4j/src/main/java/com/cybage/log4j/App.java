package com.cybage.log4j;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class App {

	public static final Logger logger = LogManager.getLogger(App.class.getName());
	public static void main(String[] args) {
		 while(true){
	            logger.info("we have started application");
	            logger.info("I am printing simple message");
	            logger.warn("application will shut down in next 5 min");
	            //        logger.error("error occurred");
	            logger.info("Application shut down");
	        }
	}
}
