package com.cyabge;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating map of books
		Map<Integer,Book> map= new HashMap<Integer,Book>();
		
		//creating books
		Book b1= new Book(101,"Wings of fire",533);
		Book b2= new Book(102,"Animal farm",200);
		Book b3= new Book(103,"lets C",400);
		
		
		//mapping the books
		map.put(1, b1);
		map.put(2, b2);
		map.put(3, b3);
		
//		//Getting a set of key-value pairs
		Set entrySet= map.entrySet();
		
		//Iterator for an entryset
		Iterator it= entrySet.iterator();
		
		//Using iterator display the list
		System.out.println("Using HashMap display the booklist :");
       while(it.hasNext()){
    	    Object key =  it.next();
    	    System.out.println("Key =" +key);
			
	    }
		
		
	//System.out.println(map);
		
	//	map.forEach((k,v)-> System.out.println("Key =" +k+ ", BOOK:" +v));


	
		

	}

}
