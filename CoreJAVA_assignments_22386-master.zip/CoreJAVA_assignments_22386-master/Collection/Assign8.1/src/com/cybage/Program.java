package com.cybage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program {
	
	public static void main(String[] args){
	Employee e1= new Employee(111,"Deepika",15000);
	Employee e2= new Employee(546,"Deepika",15000);
	Employee e3= new Employee(201,"Deepika",15000);
	Employee e4= new Employee(222,"Deepika",15000);
	Employee e5= new Employee(485,"Deepika",15000);
	Employee e6= new Employee(321,"Deepika",15000);
	
	
	
	List <Employee> employees= new ArrayList<Employee>();
	
	employees.add(e1);
	employees.add(e2);
	employees.add(e3);
	employees.add(e4);
	employees.add(e5);
	employees.add(e6);
	
	
	//Unsorted list
	System.out.println(employees);
	//sorted list
	Collections.sort(employees);
	System.out.println("Soerted by EMPID:");
	System.out.println(employees);
	}
	
}
