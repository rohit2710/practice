package com.cybage;

import java.util.ArrayList;
import java.util.Collections;
//import java.util.Comparator;
import java.util.List;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e1= new Employee(111,"Deepika",15000);
		Employee e2= new Employee(546,"Animesh",15000);
		Employee e3= new Employee(201,"Barkha",15000);
		Employee e4= new Employee(222,"Darshan",15000);
		Employee e5= new Employee(485,"Apoorv",15000);
		Employee e6= new Employee(321,"Amar",15000);
		
		
		
		List <Employee> employees= new ArrayList<Employee>();
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		employees.add(e6);
		
		
		//sorting as per the empname
		Collections.sort(employees, (o1,o2)->o1.getEmpname().compareTo(o2.getEmpname()));
		System.out.println("Sorted using Empname in Alphabetical Order:---------");
		System.out.println(employees);
		
		
	}

}
