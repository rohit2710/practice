package com.cybage.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	 public static String dbUrl = "jdbc:mysql://localhost:3306/cybage";
	    public static String dbUser = "root";
	    public static String dbPassword = "admin123";
	    
	    public static Connection getConnection() throws Exception{
	        Class.forName("com.mysql.jdbc.Driver");
	        Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
	        return con;
	    }

}
