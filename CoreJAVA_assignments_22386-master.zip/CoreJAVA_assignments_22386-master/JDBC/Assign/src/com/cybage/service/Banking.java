package com.cybage.service;

//banking rules will be defined by rbi and all bank need to adhere to rbi rules
public interface Banking {
	public static float roi = 6.5F;
	public Account openAccount(
			String accType, 
			String name, 
			String address, 
			double balance
			) throws AccountException;
	public double getBalance(String accNumber) throws AccountException;
	public double withdrawl(String accNumber, double amount) throws AccountException;
}