package com.cybage.service;

public enum AccountType {
	SAVING,
	CURRENT,
	CREDITCARD,
	HOMELOAN,
	CARLOAN,
	EDUCATIONLOAN

}
