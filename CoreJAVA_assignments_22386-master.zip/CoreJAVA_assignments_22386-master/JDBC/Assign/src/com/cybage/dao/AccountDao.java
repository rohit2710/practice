package com.cybage.dao;

import com.cybage.service.Account;

public interface AccountDao {
	 public String addAccount(Account account) throws Exception;

}
