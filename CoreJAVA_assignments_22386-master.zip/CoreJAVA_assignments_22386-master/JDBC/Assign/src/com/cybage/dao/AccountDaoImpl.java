package com.cybage.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;

 

import com.cybage.service.Account;
import com.cybage.jdbc.DbUtil;

 

public class AccountDaoImpl implements AccountDao{

 

    @Override
    public String addAccount(Account account) throws Exception {
        String sql = "insert into account values(?, ?, ?, ?)";
        Connection con = DbUtil.getConnection();
        con.setAutoCommit(false);
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, account.getAccNumber());
        ps.setString(2, account.getAccType());
        ps.setString(3, account.getCustId());
        ps.setDouble(4, account.getBalance());

 

        if(ps.executeUpdate() == 1) {
            con.commit();            //customer + account will be committed
            ps.close(); 
            con.close();  
            return account.getAccNumber();
        }
        else{ 
            con.rollback();
            ps.close(); 
            con.close(); 
            return null;
        }
    }
}
