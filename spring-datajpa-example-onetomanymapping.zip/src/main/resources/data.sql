insert into employee values(101,"rv101");
insert into employee values(102,"rv102");
insert into employee values(103,"rv103");
insert into employee values(104,"rv104");
insert into employee values(105,"rv105");