package com.example.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.entity.Customer;
import com.example.repository.CustomerRepository;

@Controller
public class CustomerController {
	
	@Autowired CustomerRepository cr;
	
	@RequestMapping("/")
	public String home() {
		return "index";
	}

	@GetMapping(value = "/customers")
	public String getUser(Model model) {
		model.addAttribute("customers", cr.findAll());
		return "customer";
	}
	@GetMapping(value = "/showform")
	public String showForm(Model model)
	{
		model.addAttribute("customer", new Customer());
		return "register";
	}
	
	@PostMapping(value = "/addcustomer")
	public String addCustomer(@ModelAttribute("customer") Customer customer, BindingResult result)
	{
		if(result.hasErrors())
		{
			return "register";
		}
		//userDao.addUser(customer);
		return "redirect:/customers";
	}
}
