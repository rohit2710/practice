package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import com.example.entity.Account;
import com.example.entity.Customer;
import com.example.entity.Employee;
import com.example.entity.Phone;
import com.example.repository.AccountRepository;
import com.example.repository.CustomerRepository;
import com.example.repository.EmployeeRepository;
import com.example.repository.PhoneRepository;

@SpringBootApplication
@ComponentScan("com.example.controller")
public class SpringDatajpaExampleApplication implements CommandLineRunner{
	public static void main(String[] args) {
		SpringApplication.run(SpringDatajpaExampleApplication.class, args);
	}

	@Autowired
	PhoneRepository pr;
	
	@Autowired
	CustomerRepository cr;
	


	@Override
	public void run(String... args) throws Exception {
		 List<Phone> phones = new ArrayList<>();
         phones.add(new Phone(896874541));
//         phones.add(new Phone(896874541));
//         phones.add(new Phone(896874541));



         Customer customer = new Customer(1 , "rv1", "rv1", "5445745", phones);
        
         cr.save(customer);
         System.out.println(cr.findById(1));         
	}
}

























//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//import com.example.entity.Employee;
//import com.example.repository.EmployeeRepository;
//
//@SpringBootApplication(scanBasePackages = "com.example")
//public class SpringDatajpaExampleApplication implements CommandLineRunner{
//
//	public static void main(String[] args) {
//		SpringApplication.run(SpringDatajpaExampleApplication.class, args);
//	}
//
//	@Autowired
//	EmployeeRepository er;
//	UserRepository ur
//	@Override
//	public void run(String... args) throws Exception {
//
//		
//		//		er.save(new Employee(101,"rv101"));
////		er.save(new Employee(102,"rv102"));
////		er.save(new Employee(103,"dv103"));
////		er.save(new Employee(104,"rv104"));
//		
//		//System.out.println(er.pqr("rv102"));
//		//System.out.println(er.findById(102));
//		//System.out.println(er.pqr("rv104"));
//		//System.out.println(er.findByEmployee(new Employee(104,"rv104")));
//		//System.out.println(er.findByName("rv102"));
//
//		//System.out.println(er.findByIdAndName(101, "rv101"));
//		
//	}
//
//}
