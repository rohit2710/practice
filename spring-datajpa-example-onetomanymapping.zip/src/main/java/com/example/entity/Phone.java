package com.example.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Phone {
	@Id
	private int phoneNo;
	
	public Phone() {
		super();
	}

	public Phone(int phoneNo) {
		super();
		this.phoneNo = phoneNo;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Phone [phoneNo=" + phoneNo + "]";
	}
	
}
